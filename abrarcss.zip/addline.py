def add_new_line_after_properties(input_file, output_file):
    with open(input_file, 'r') as infile:
        content = infile.read()

    # Add a new line after each CSS property
    content_with_new_lines = content.replace(';', ';\n')

    with open(output_file, 'w') as outfile:
        outfile.write(content_with_new_lines)

    print(f"New lines added after CSS properties. Output written to {output_file}")

# Example usage:
input_file_path = "fixy2.css"
output_file_path = "fixy5.css"
add_new_line_after_properties(input_file_path, output_file_path)

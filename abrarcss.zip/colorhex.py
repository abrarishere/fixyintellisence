def generate_fixy4_css():
    with open("fixy4.css", "w") as f:
        f.write("/* fixy4.css - CSS classes for colors */\n\n")

        # Generate a smaller subset of color classes
        for r in range(0, 256, 16):
            for g in range(0, 256, 16):
                for b in range(0, 256, 16):
                    hex_color = "#{:02x}{:02x}{:02x}".format(r, g, b)
                    f.write(".color-{}-hex {{ color: {}; }}\n".format(hex_color[1:], hex_color))
                    f.write(".bg-{}-hex {{ background-color: {}; }}\n".format(hex_color[1:], hex_color))

    print("fixy4.css generated successfully!")

generate_fixy4_css()

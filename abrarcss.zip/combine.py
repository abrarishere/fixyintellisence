def combine_css_files(input_files, output_file):
    with open(output_file, 'w') as outfile:
        for input_file in input_files:
            with open(input_file, 'r') as infile:
                outfile.write(infile.read())
                outfile.write('\n\n')  # Add extra new lines between the contents of each file

    print(f"CSS files combined successfully. Output written to {output_file}")

# Example usage:
input_file_paths = ["file1.css", "file2.css", "file3.css", "file4.css", "file5.css"]
output_file_path = "combined_styles.css"
combine_css_files(input_file_paths, output_file_path)

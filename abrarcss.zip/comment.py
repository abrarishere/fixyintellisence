import re

def remove_comments(input_file, output_file):
    with open(input_file, 'r') as infile:
        content = infile.read()

    # Remove /* */ comments
    content_without_comments = re.sub(r'/\*.*?\*/', '', content, flags=re.DOTALL)

    with open(output_file, 'w') as outfile:
        outfile.write(content_without_comments)

    print(f"Comments removed. Output written to {output_file}")

# Example usage:
input_file_path = "fixy2.css"
output_file_path = "fixy5.css"
remove_comments(input_file_path, output_file_path)

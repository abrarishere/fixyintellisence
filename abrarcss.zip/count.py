def count_letters(content):
    letter_count = sum(c.isalpha() for c in content)
    return letter_count

def count_letters_in_file(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            file_content = file.read()
            total_letters = count_letters(file_content)
            print(f"Total letters in the file {file_path}: {total_letters}")
    except FileNotFoundError:
        print(f"File not found: {file_path}")
    except Exception as e:
        print(f"Error reading file: {e}")

# Replace 'your_file.txt' with the path to your file
count_letters_in_file('fixy1.css')
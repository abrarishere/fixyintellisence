with open("fixy1.css", "w") as file:
    # Margin and Padding
    for i in range(301):
        file.write('.m-{} {{margin: {}px;}}'.format(i, i))
        file.write('.m-{}rem {{margin: {}rem;}}'.format(i, i))
        file.write('.p-{} {{padding: {}px;}}'.format(i, i))
        file.write('.p-{}rem {{padding: {}rem;}}'.format(i, i))

        file.write('.m-top-{} {{margin-top: {}px;}}'.format(i, i))
        file.write('.m-bottom-{} {{margin-bottom: {}px;}}'.format(i, i))
        file.write('.m-left-{} {{margin-left: {}px;}}'.format(i, i))
        file.write('.m-right-{} {{margin-right: {}px;}}'.format(i, i))

        file.write('.p-top-{} {{padding-top: {}px;}}'.format(i, i))
        file.write('.p-bottom-{} {{padding-bottom: {}px;}}'.format(i, i))
        file.write('.p-left-{} {{padding-left: {}px;}}'.format(i, i))
        file.write('.p-right-{} {{padding-right: {}px;}}'.format(i, i))

    # Height and Width
    for i in range(301):
        file.write('.h-{} {{height: {}px;}}'.format(i, i))
        file.write('.h-{}vh {{height: {}vh;}}'.format(i, i))
        file.write('.h-{}pct {{height: {}%;}}'.format(i, i))

        file.write('.w-{} {{width: {}px;}}'.format(i, i))
        file.write('.w-{}pct {{width: {}%;}}'.format(i, i))
        file.write('.w-{}vh {{width: {}vh;}}'.format(i, i))

    # Font Size
    for i in range(1, 101):
        file.write('.font-size-{} {{font-size: {}px;}}'.format(i, i))

    # Position
    for i in range(301):
        file.write('.t-{} {{top: {}px;}}'.format(i, i))
        file.write('.l-{} {{left: {}px;}}'.format(i, i))
        file.write('.b-{} {{bottom: {}px;}}'.format(i, i))
        file.write('.r-{} {{right: {}px;}}'.format(i, i))


    # Line Height and Border Radius
    for i in range(301):
        file.write('.l-h-{} {{line-height: {}px;}}'.format(i, i))
        file.write('.border-radius-{} {{border-radius: {}px;}}'.format(i, i))

        file.write('.border-radius-{}pct {{border-radius: {}%;}}'.format(i, i))

        file.write('.z-index-{} {{z-index: {};}}'.format(i, i))
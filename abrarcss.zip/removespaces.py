def remove_space_and_newline(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            file_content = file.read()
            cleaned_content = file_content.replace(" ", "").replace("\n", "")
            
            with open(file_path, 'w', encoding='utf-8') as modified_file:
                modified_file.write(cleaned_content)
            
            print(f"Spaces and newlines removed from the file: {file_path}")
    except FileNotFoundError:
        print(f"File not found: {file_path}")
    except Exception as e:
        print(f"Error processing file: {e}")

# Replace 'your_file.txt' with the path to your file
remove_space_and_newline('fixy2.css')
with open("fixybulk2.css", "w") as f:
    f.write("/* Gap properties */\n\n")

    # Generate gap properties in pixels
    for i in range(1, 101):
        f.write(".gap-{}-px {{ gap: {}px; }}".format(i, i))
        
    # Generate gap properties in rems
    for i in range(1, 101):
        f.write(".gap-{}-rem {{ gap: {}rem; }}".format(i, i))

print("Gap properties generated successfully!")
